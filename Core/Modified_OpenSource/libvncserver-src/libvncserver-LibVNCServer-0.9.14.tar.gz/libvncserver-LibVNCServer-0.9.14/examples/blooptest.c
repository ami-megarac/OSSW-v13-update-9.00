/**
  @example blooptest.c
  blooptest is a test of pthreads. It is just the example, but with a background
  loop to hunt down thread lockups.
 */
#define BACKGROUND_LOOP_TEST
#include "example.c"
