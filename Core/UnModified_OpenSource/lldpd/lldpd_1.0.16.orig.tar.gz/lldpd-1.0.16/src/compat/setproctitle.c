/* -*- mode: c; c-file-style: "openbsd" -*- */

void
setproctitle(const char *fmt, ...)
{
	/* Do nothing. */
}
