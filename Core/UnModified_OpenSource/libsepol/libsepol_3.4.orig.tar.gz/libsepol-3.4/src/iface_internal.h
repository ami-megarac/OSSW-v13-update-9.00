#ifndef _SEPOL_IFACE_INTERNAL_H_
#define _SEPOL_IFACE_INTERNAL_H_

#include <sepol/iface_record.h>
#include <sepol/interfaces.h>

#endif
