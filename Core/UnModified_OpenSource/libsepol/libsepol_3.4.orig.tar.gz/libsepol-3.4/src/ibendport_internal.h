#ifndef _SEPOL_IBENDPORT_INTERNAL_H_
#define _SEPOL_IBENDPORT_INTERNAL_H_

#include <sepol/ibendport_record.h>
#include <sepol/ibendports.h>

#endif
